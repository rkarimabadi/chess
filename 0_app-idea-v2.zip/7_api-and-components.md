# معماری API و کامپوننت‌های فرانت‌اند

> تفکیک ماژولار API Endpoints و کامپوننت‌های فرانت‌اند. **جایگزینی GPS با District + QR Code + Manual Status در سراسر API و کامپوننت‌ها.**

---

## 🌐 بخش اول: معماری API Endpoints

### ۱. مدیریت شیفت‌ها (Shift Management)

|HTTP Verb|Endpoint|نقش|Request Body / Params|Response|خطاها|
|---|---|---|---|---|---|
|POST|`/api/v1/pharmacies/shifts`|Pharmacy|`CreateShiftRequestDto`|`ShiftDto` (۲۰۱)|400/402/422|
|GET|`/api/v1/pharmacies/shifts/{id}`|Pharmacy, Tech|—|`ShiftDetailsDto`|403/404|
|GET|`/api/v1/pharmacies/shifts`|Pharmacy|`?status=&date=&districtId=`|`List<ShiftSummaryDto>`|—|
|PATCH|`/api/v1/pharmacies/shifts/{id}/cancel`|Pharmacy|`CancelShiftDto`|`CancellationResultDto`|400/403/409|
|GET|`/api/v1/technicians/offers`|Technician|`?districtId=`|`List<ShiftOfferDto>`|—|

> **تغییر:** پارامتر `?lat=&lng=&radius=` → `?districtId=`
> پارامتر `?status=&date=` → `?status=&date=&districtId=`

#### POST /api/v1/pharmacies/shifts — Request & Response

```json
// Request
{
  "urgencyLevel": "Immediate",
  "startTime": "2026-07-29T16:30:00Z",
  "endTime": "2026-07-29T21:30:00Z",
  "requiredRole": "Dispenser",
  "requiredSoftware": "RayanTab",
  "minProficiency": "Intermediate",
  "urgencyBonus": 50000,
  "targetGoldenTechniciansOnly": true
}
// DistrictId از پروفایل داروخانه خوانده می‌شود
```

```json
// Response 201
{
  "shiftId": "3fa85f64-5717-4562-b3fc-2c963f66a700",
  "status": "Open",
  "totalAmount": 330000,
  "districtId": "...",
  "districtName": "منطقه ۱۲",
  "estimatedMatchTimeSeconds": 15,
  "createdAt": "2026-07-29T16:00:00Z"
}
```

---

### ۲. موتور تطبیق و کاندیداها (Matching & Candidates)

|HTTP Verb|Endpoint|نقش|توضیح|
|---|---|---|---|
|GET|`/api/v1/pharmacies/shifts/{id}/candidates`|Pharmacy|لیست متقاضیان با Matching Score|
|POST|`/api/v1/shifts/{id}/apply`|Technician|پذیرش شیفت (Swipe)|
|POST|`/api/v1/pharmacies/shifts/{id}/select-candidate`|Pharmacy|انتخاب نهایی|

#### GET .../candidates — Response

```json
{
  "shiftId": "...",
  "status": "Matching",
  "districtId": "...",
  "candidates": [
    {
      "technicianId": "guid-1",
      "fullName": "علی محمدی",
      "rating": 4.9,
      "totalCompletedShifts": 42,
      "softwareProficiency": "Expert",
      "districtOverlap": "SameDistrict",
        // SameDistrict | AdjacentDistrict | Different
      "priorShiftsInThisPharmacy": 3,
      "matchingScore": 96.5,
      "reliabilityRate": 98.2
    }
  ],
  "totalReceived": 3,
  "autoAssignTimerSeconds": 60
}
```

> **تغییر:** فیلد `distanceKm` و `estimatedArrivalMinutes` حذف شد — `districtOverlap` جایگزین

---

### ۳. حضور و غیاب و پاس شیفت (Attendance & QR Check-in)

|HTTP Verb|Endpoint|نقش|توضیح|
|---|---|---|---|
|GET|`/api/v1/shifts/{id}/pass`|Technician|دریافت Shift Pass|
|POST|`/api/v1/attendance/check-in`|Technician|ثبت ورود با QR Code|
|POST|`/api/v1/attendance/check-out`|Technician|ثبت خروج|
|POST|`/api/v1/pharmacies/shifts/{id}/confirm-attendance`|Pharmacy|تأیید دستی|

#### POST /api/v1/attendance/check-in — Request & Response

```json
// Request — GPS و location حذف شد، QR Code جایگزین
{
  "shiftId": "3fa85f64-5717-4562-b3fc-2c963f66a700",
  "technicianId": "guid-1",
  "qrCode": "a1b2c3d4-...",
  "deviceTimestamp": "2026-07-29T16:25:00Z"
}

// Response 200
{
  "status": "CheckedIn",
  "checkInTime": "2026-07-29T16:25:00Z",
  "checkInMethod": "QRCode",
  "isVerified": true
}

// Response 400 — QR Invalid/Expired
{
  "error": "QR_INVALID_OR_EXPIRED",
  "message": "QR Code نامعتبر یا منقضی شده است. از مسئول فنی بخواهید QR جدیدی تولید کند."
}

// Response 200 — Fallback: Manual Confirm
// (زمانی که مسئول فنی دکمه تأیید را می‌زند)
{
  "status": "CheckedIn",
  "checkInTime": "...",
  "checkInMethod": "ManualConfirm",
  "isVerified": true,
  "confirmedBy": "Pharmacy Manager"
}

// Response 200 — QR نیازمند تأیید نهایی
{
  "status": "PendingVerification",
  "checkInTime": "...",
  "checkInMethod": "QRCode",
  "isVerified": false,
  "message": "منتظر تأیید نهایی مسئول فنی"
}
```

> **تغییر:** فیلد `location`, `isGeofenceVerified`, `distanceToPharmacyMeters` حذف شد
> فیلد `qrCode`, `checkInMethod`, `isVerified` اضافه شد

#### POST /api/v1/pharmacies/shifts/{id}/generate-qr — Endpoint جدید

```
POST /api/v1/pharmacies/shifts/{id}/generate-qr  (Pharmacy)
→ { "qrCode": "guid", "expiresAt": "2026-07-29T16:26:00Z" }
// QR جدید روی مانیتور داروخانه نمایش داده می‌شود
```

#### GET /api/v1/shifts/{id}/pass — Response

```json
{
  "passId": "pass-1",
  "pharmacy": {
    "name": "داروخانه دکتر ابراهیمی",
    "district": "منطقه ۱۲",
    "address": "میدان فردوسی",
    "phone": "۰۲۱-XXXXXXX"
  },
  "playbook": {
    "layoutMap": "داروی خارجی: قفسه A1-A5 | یخچال: انتهای سالن راست",
    "software": { "name": "رایان‌طب", "guestUser": "guest", "guestPass": "1234" },
    "contact": { "name": "دکتر ابراهیمی", "maskedPhone": "۰۹۱۲-XXX-XXXX" },
    "rules": [ "پوشش: روپوش سفید", "تحویل صندوق الزامی است" ]
  },
  "techStatus": "OnTheWay"
    // Accepted | OnTheWay | Arrived | CheckedIn | CheckedOut
}
```

---

### ۴. تسویه مالی و ارزیابی (Escrow, Wallet & Review)

*(بدون تغییر وابسته به GPS)*

|HTTP Verb|Endpoint|نقش|
|---|---|---|
|GET|`/api/v1/wallets/{ownerId}`|Pharmacy, Tech|
|POST|`/api/v1/wallets/deposit`|Pharmacy|
|POST|`/api/v1/wallets/payout`|Technician|
|GET|`/api/v1/wallets/{ownerId}/transactions`|Pharmacy, Tech|
|POST|`/api/v1/reviews`|Pharmacy, Tech|
|GET|`/api/v1/reviews/{shiftId}`|Pharmacy, Tech|

---

### 📡 سرویس‌های Real-time (SignalR Hubs)

#### Hub: `/hubs/shift-broadcaster`

|متد (Server → Client)|Payload|مخاطب|شرط ارسال|
|---|---|---|---|
|`ReceiveUrgentOffer`|`ShiftOfferDto`|تکنسین خاص|شیفت Immediate در منطقه تحت پوشش|
|`CandidateListUpdated`|`List<CandidateDto>`|داروخانه|کاندیدای جدید اضافه شد|
|`TechnicianStatusChanged`|`TechStatusDto { Status, ETAMinutes }`|داروخانه|تکنسین وضعیت دستی را تغییر داد|
|`ShiftAssignedNotification`|`ShiftAssignedDto`|تکنسین|داروخانه تأیید کرد|
|`ShiftCancelledAlert`|`ShiftCancelledDto`|تکنسین|شیفت لغو شد|

|متد (Client → Server)|Payload|توضیح|
|---|---|---|
|`UpdateTechStatus`|`{ status: "OnTheWay" | "Arrived", etaMinutes: number }`|تکنسین وضعیت خود را手动 به‌روز می‌کند|
|`AcceptOffer`|`{ shiftId }`|تکنسین شیفت را می‌پذیرد|

> **تغییر:** `UpdateLocation{ lat, lng, heading }` → `UpdateTechStatus{ status, etaMinutes }`
> `TechnicianStatusChanged` دیگر `LocationStatusDto` ندارد — `TechStatusDto` جایگزین

#### نمونه SignalR Event — ReceiveUrgentOffer

```json
{
  "shiftId": "...",
  "pharmacyName": "داروخانه دکتر ابراهیمی",
  "district": "منطقه ۱۲",
  "totalPayout": 300000,
  "startTime": "2026-07-29T16:30:00Z",
  "endTime": "2026-07-29T21:30:00Z",
  "requiredSoftware": "RayanTab",
  "acceptDeadlineSeconds": 120
}
```

> **تغییر:** فیلد `distanceKm` حذف شد — `district` اضافه شد

#### جدول مقایسه HTTP vs SignalR

|سناریو|پروتکل|دلیل|
|---|---|---|
|ثبت شیفت|HTTP POST|عملیات اتمی|
|دریافت لیست کاندیدا|HTTP GET + SSE|Real-time یک‌طرفه|
|Swipe to Accept|HTTP POST|Idempotent|
|بروزرسانی وضعیت تکنسین|SignalR|نیاز به اطلاع‌رسانی لحظه‌ای به داروخانه|
|اعلان فوری به تکنسین|SignalR|زیر ۱ ثانیه تأخیر|
|**GPS Tracking**|**حذف شد**|**جایگزین: وضعیت دستی از طریق SignalR**|

---

### خلاصه کامل API Endpoints

|#|متد|مسیر|Context|Rate Limit|تغییر|
|---|---|---|---|---|---|
|1|POST|`/api/v1/pharmacies/shifts`|Shift|۱۰/min|—|
|2|GET|`/api/v1/pharmacies/shifts`|Shift|۳۰/min|اضافه شدن `?districtId=`|
|3|GET|`/api/v1/pharmacies/shifts/{id}`|Shift|۳۰/min|—|
|4|PATCH|`/api/v1/pharmacies/shifts/{id}/cancel`|Shift|۵/min|—|
|5|GET|`/api/v1/technicians/offers`|Matching|۳۰/min|`?lat=&lng=&radius=` → `?districtId=`|
|6|GET|`/api/v1/shifts/{id}/candidates`|Matching|۳۰/min|Response تغییر کرد|
|7|POST|`/api/v1/shifts/{id}/apply`|Matching|۱۰/min|—|
|8|POST|`/api/v1/shifts/{id}/select-candidate`|Matching|۱۰/min|—|
|9|GET|`/api/v1/shifts/{id}/pass`|Playbook|۳۰/min|Response تغییر کرد|
|10|POST|`/api/v1/attendance/check-in`|Attendance|۵/min|Body + Response تغییر کرد|
|11|POST|`/api/v1/attendance/check-out`|Attendance|۵/min|—|
|12|POST|`/api/v1/attendance/confirm`|Attendance|۱۰/min|—|
|13|**POST**|**`/api/v1/shifts/{id}/generate-qr`**|**Attendance**|**۱۰/min**|**Endpoint جدید**|
|14|POST|`/api/v1/shifts/{id}/update-status`|Shift|۱۰/min|**Endpoint جدید** — وضعیت دستی تکنسین|
|15|GET|`/api/v1/wallets/{id}`|Escrow|۳۰/min|—|
|16|POST|`/api/v1/wallets/deposit`|Escrow|۳/min|—|
|17|POST|`/api/v1/wallets/payout`|Escrow|۳/min|—|
|18|POST|`/api/v1/reviews`|Reputation|۵/min|—|
|19|GET|`/api/v1/reviews/{shiftId}`|Reputation|۳۰/min|—|

---

## 🧩 بخش دوم: معماری کامپوننت‌های فرانت‌اند

### ساختار دایرکتوری (به‌روز شده)

```
src/
├── shared/
│   ├── atoms/
│   │   ├── Button.razor
│   │   ├── TextInput.razor
│   │   ├── StarRating.razor
│   │   ├── Timer.razor
│   │   └── DistrictBadge.razor              # NEW: نشان منطقه
│   ├── molecules/
│   │   ├── PharmacyInfoCard.razor
│   │   ├── FinancialSummaryBox.razor
│   │   └── TechStatusSelector.razor          # NEW: انتخابگر وضعیت دستی
│   └── organisms/
│       ├── SwipeToAccept.razor
│       └── QRCodeScanner.razor               # NEW: اسکنر QR Code
│
├── features/
│   ├── shift-management/
│   │   ├── components/
│   │   │   ├── EmergencyShiftForm.razor
│   │   │   ├── DynamicPricingCalculator.razor
│   │   │   ├── CandidateList.razor
│   │   │   ├── CandidateCard.razor           # distanceKm → districtOverlap
│   │   │   └── DistrictSelector.razor        # NEW (اختیاری برای ادمین)
│   │   └── pages/
│   │       ├── CreateShiftPage.razor
│   │       └── ShiftCandidatesPage.razor
│   │
│   ├── shift-execution/
│   │   ├── components/
│   │   │   ├── ShiftOfferCard.razor
│   │   │   ├── ShiftPassCard.razor
│   │   │   ├── OnboardingPlaybookWidget.razor
│   │   │   └── QRCodeCheckInButton.razor     # RENAMED: Geofence → QRCode
│   │   └── pages/
│   │       ├── ActiveShiftPage.razor
│   │       └── OfferDetailsPage.razor
│   │
│   └── settlement-reviews/
│       ├── components/
│       │   ├── InstantPayoutWidget.razor
│       │   └── DoubleBlindReviewModal.razor
│       └── pages/
│           └── SettlementPage.razor
│
├── services/
│   ├── ShiftApiService.cs
│   ├── AttendanceApiService.cs
│   ├── WalletApiService.cs
│   └── SignalRService.cs
│
└── models/
    ├── ShiftDto.cs
    ├── CandidateDto.cs                      # distanceKm → districtOverlap
    ├── ShiftPassDto.cs
    └── ReviewDto.cs
```

---

### جزئیات کامپوننت‌های کلیدی

#### ۱. ShiftOfferCard

|عنصر|توضیح|
|---|---|
|**وضعیت‌ها**|`Loading` / `Active` / `Swiping` / `Accepted` / `Expired` / `Declined`|
|**State محلی**|`IsSwiping`, `SwipeProgress`, `TimeRemainingSeconds`, `TechStatus`|
|**Props ورودی**|`ShiftOfferDto`, `CountdownSeconds`|
|**Events خروجی**|`OnAccepted(Guid)`, `OnExpired(Guid)`, `OnDeclined(Guid)`|
|**تغییر**|`GPSStatus` → `TechStatus` (دستی)|

#### ۲. QRCodeCheckInButton (قبلاً: GeofenceCheckInButton)

|عنصر|توضیح|
|---|---|
|**وضعیت‌ها**|`Ready` / `Scanning` / `Validating` / `Success` / `InvalidQR` / `ManualConfirm`|
|**State محلی**|`ScanResult`, `QrExpiresAt`, `IsVerified`|
|**Props ورودی**|`ShiftId`, `TechnicianId`, `PharmacyId`|
|**منطق داخلی**|۱. باز کردن دوربین → ۲. اسکن QR → ۳. `POST /attendance/check-in` → ۴. نمایش نتیجه|
|**Fallback**|دکمه «درخواست تأیید دستی» — اطلاع به مسئول فنی|
|**تغییر**|**جایگزین کامل GeofenceCheckInButton** — GPS Polling و Haversine حذف شد|

#### ۳. TechStatusSelector (کامپوننت جدید)

|عنصر|توضیح|
|---|---|
|**وضعیت‌ها**|`NotOnShift` / `OnTheWay` / `Arrived` / `CheckedIn`|
|**State محلی**|`CurrentStatus`, `ETAMinutes` (فقط در حالت OnTheWay)|
|**Props ورودی**|`ShiftId`, `InitialStatus`|
|**Events خروجی**|`OnStatusChanged(ShiftId, Status, ETAMinutes)`|
|**UI**|۳ دکمه: «در مسیرم» / «رسیدم» / «شروع کردم» + (اختیاری) Input برای ETA|
|**اثر جانبی**|ارسال SignalR `UpdateTechStatus` به داروخانه|

---

### Data Flow — End-to-End (به‌روز شده)

```
[تکنسین]                              [API Gateway]                    [داروخانه]
   │                                       │                              │
   ├─ SignalR: ReceiveUrgentOffer ─────────┤                              │
   │                                       │                              │
   ├─ نمایش ShiftOfferCard                 │                              │
   │                                       │                              │
   ├─ ═══ Swipe to Accept ═══             │                              │
   │                                       │                              │
   ├─ POST /shifts/{id}/apply ────────────→┤                              │
   │                                       ├─ SignalR: CandidateAdded ──→│
   │                                       │                              │
   │                                       │←── POST /select-candidate ──┤
   │                                       │                              │
   ├─ SignalR: ShiftAssigned ←────────────┤                              │
   │                                       │                              │
   ├─ نمایش ShiftPass                      │                              │
   │                                       │                              │
   ├─ SignalR: UpdateTechStatus ──────────→┤                              │
   │   "OnTheWay", ETA: 15 دقیقه          ├─ SignalR: StatusChanged ───→│
   │                                       │                              │
   ├─ اسکن QR (دوربین)                     │                              │
   │                                       │                              │
   ├─ POST /attendance/check-in ──────────→┤                              │
   │   { qrCode: "guid" }                 ├─ SignalR: CheckedIn ───────→│
   │                                       │                              │
   ├─ POST /attendance/check-out ─────────→┤                              │
   │                                       ├─ Event: CheckOutCompleted ─→│
   │                                       │   (→ Escrow Release)        │
   │                                       │                              │
   ├─ نمایش SettlementPage                 │                              │
   │                                       │                              │
   ├─ POST /reviews ──────────────────────→┤                              │
   │                                       │←── POST /reviews ───────────┤
   │                                       │   (Double-Blind Unlock)     │
```
