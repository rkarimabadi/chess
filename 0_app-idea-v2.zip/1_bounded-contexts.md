# تفکیک مرزهای سامانه (Bounded Contexts)

> معماری سامانه بر اساس اصول Domain-Driven Design (DDD) به ۷ باندد کانتکست مجزا تفکیک شده است. در این طراحی به جای GPS و موقعیت‌یابی مکانی از سامانه **منطقه (District) + QR Code پویا + وضعیت دستی** استفاده می‌شود.

---

## ۱. کانتکست هویت، صلاحیت و ماتریس مهارت (Identity & Competency)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|ثبت، احراز و نگهداشت پروفایل طرفین + ماتریس مهارت‌ها + مناطق تحت پوشش|
|**هسته (Agg. Root)**|`Technician`, `Pharmacy`|
|**جدول مرجع**|`Districts` — شامل استان، شهر، منطقه، محله|

### پروفایل تکنسین

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتای سامانه‌ای|
|`UserId`|Guid|✓|FK به Auth System|
|`FullName`|String|✓|نام و نام خانوادگی|
|`NationalCode`|String (۱۰ رقمی)|✓|کد ملی منحصربه‌فرد|
|`PhoneNumber`|String|✓|شماره تماس اصلی|
|`Status`|TechnicianStatusEnum|✓|`PendingVerification` → `Active` → `Suspended`|
|`ReliabilityScore`|Decimal (۰-۵)|✓|محاسبه‌شده از رویدادهای کانتکست ۷|
|`ServiceDistricts`|List<DistrictId>|✓|مناطق تحت پوشش (چند选区)|
|`SoftwareSkills`|List|✓|ماتریس تسلط نرم‌افزاری|
|`Certificates`|List|✗|مدارک و گواهی‌نامه‌ها|

**Invariants:**
- حداقل یک منطقه تحت پوشش باید انتخاب شده باشد
- `ReliabilityScore` همیشه بین ۰ و ۵
- یک تکنسین `Suspended` نمی‌تواند شیفت جدید بپذیرد

**ماتریس مهارت نرم‌افزاری (TechnicianSoftwareSkill):**
- `SoftwareId: SoftwareTypeEnum` (RayanTab, EmenAfzar, Sharpel, Hami, Simorgh, ...)
- `ProficiencyLevel: ProficiencyLevelEnum` (Beginner, Intermediate, Expert)
- **Invariant:** حداقل یکی از نرم‌افزارها باید سطح `Intermediate` یا بالاتر داشته باشد

**Domain Service — `SkillVerificationService`:**
- ورودی: `TechnicianId` + `PharmacySoftwareType`
- خروجی: `(IsQualified: bool, MatchLevel: ProficiencyLevelEnum)`

### پروفایل داروخانه

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتای سامانه‌ای|
|`OwnerUserId`|Guid|✓|FK به مالک|
|`Name`|String|✓|نام داروخانه|
|`LicenseNumber`|String|✓|شماره پروانه تأسیس|
|`DistrictId`|Guid|✓|منطقه داروخانه (FK به Districts)|
|`Address`|AddressValueObject|✓|استان، شهر، خیابان، کدپستی|
|`PrimarySoftware`|SoftwareTypeEnum|✓|نرم‌افزار اصلی|
|`SoftwareVersion`|String|✗|نسخه نرم‌افزار|
|`PhoneNumber`|String|✓|شماره تماس داروخانه|
|`OnboardingPlaybook`|PlaybookValueObject|✗|راهنمای آنبوردینگ داروخانه|

**Repository Contracts:**
- `ITechnicianRepository`: `GetById`, `FindQualified(SoftwareType, DistrictId, MinScore)`, `GetByPhone`
- `IPharmacyRepository`: `GetById`, `FindByDistrict(DistrictId)`

**رویدادهای خروجی:**
- `TechnicianVerifiedEvent{TechnicianId, VerifiedAt}`
- `PharmacyProfileUpdatedEvent{PharmacyId, UpdatedFields}`
- `ReliabilityScoreChangedEvent{TechnicianId, OldScore, NewScore}`

---

## ۲. کانتکست چرخه حیات شیفت (Shift Lifecycle)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|ثبت، انتشار، وضعیت‌سنجی و خاتمه درخواست‌های شیفت|
|**هسته (Agg. Root)**|`ShiftRequest`, `ShiftCandidate`|
|**زبان ubiquitous**|«شیفت فوری»، «فراخوان»، «متقاضی»، «پیشنهاد»|

### موجودیت ShiftRequest

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتا|
|`PharmacyId`|Guid|✓|FK به داروخانه|
|`AssignedTechnicianId`|Guid?|✗|تا زمان تأیید null|
|`Status`|ShiftStatusEnum|✓|Draft → Open → Assigned → InProgress → Completed → Settled|
|`UrgencyLevel`|UrgencyLevelEnum|✓|Immediate / SameDay / Scheduled|
|`StartTime`|DateTimeOffset|✓|شروع شیفت|
|`EndTime`|DateTimeOffset|✓|پایان شیفت|
|`RequiredSoftware`|SoftwareTypeEnum|✓|نرم‌افزار الزامی|
|`MinProficiencyLevel`|ProficiencyLevelEnum|✓|حداقل سطح تسلط|
|`RequiredRole`|RoleEnum|✓|Dispenser / Cosmetics / Operator|
|`Pricing`|ShiftPricingValueObject|✓|→ زیر|
|`PharmacyDistrictId`|Guid|✓|کپی از منطقه داروخانه (برای فیلتر تطبیق)|
|`CreatedAt`|DateTimeOffset|✓|زمان ثبت|

### Value Object — ShiftPricing

|فیلد|نوع|توضیح|
|---|---|---|
|`BaseHourlyRate`|Decimal|نرخ پایه ساعتی|
|`UrgencyBonus`|Decimal|پاداش اضطرار|
|`PlatformFee`|Decimal|کارمزد پلتفرم|
|`TotalAmount`|Decimal|مجموع = Base + Bonus + Fee|

**Invariant:** `TotalAmount` == مجموع اجزاء

### ماشین حالت شیفت

```
State     │  Trigger                │  Guard                              │  Action
──────────┼─────────────────────────┼─────────────────────────────────────┼─────────────────────
Draft     │  Publish()              │  Pricing.TotalAmount ≥ 0            │ → Open, ShiftCreatedEvent
Open      │  Assign(techId)         │  HasCandidate(techId) = true        │ → Assigned, ShiftAssignedEvent
Open      │  Cancel()               │  Candidates.Count = 0               │ → Cancelled
Open      │  ExpireTimeout()        │  CreatedAt + 30min بدون کاندیدا     │ → Cancelled
Assigned  │  Start(techId)          │  Now ≥ StartTime                    │ → InProgress
Assigned  │  Cancel(initiator)      │  ValidCancelCondition()             │ → Cancelled, PenaltyEvent
InProgress│  Complete()             │  CheckOutConfirmed = true           │ → Completed
Completed │  Settle()               │  Automatic (پس از Review)            │ → Settled
```

**رویدادهای خروجی:**
- `ShiftCreatedEvent{ShiftId, PharmacyId, UrgencyLevel, RequiredSoftware, DistrictId}`
- `ShiftAssignedEvent{ShiftId, TechnicianId, Pricing}`
- `ShiftCompletedEvent{ShiftId, TechnicianId}`
- `ShiftCancelledEvent{ShiftId, Initiator, Penalty}`

---

## ۳. کانتکست موتور تطبیق (Smart Matching Engine)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|محاسبه نمره تطبیق، انتشار پلکانی فراخوان بر اساس مناطق|
|**بدون Entity مستقل**|Stateless — خروجی به `ShiftCandidate` می‌رود|

### Domain Service — `MatchingService`

```
Score = w₁·S_soft + w₂·D_district + w₃·R_tech + w₄·H_history
```

|وزن|محدوده|متغیر|منبع داده|توضیح|
|---|---|---|---|---|
|w₁ = ۰.۴|۰ / ۱۰۰|`S_soft`|`Technician.SoftwareSkills`|۱۰۰ = تطابق کامل; ۰ = عدم تطابق → **حذف قطعی**|
|w₂ = ۰.۲۵|۰ / ۵۰ / ۱۰۰|`D_district`|`Technician.ServiceDistricts` vs `Pharmacy.DistrictId`|۱۰۰ = همان منطقه; ۵۰ = منطقه مجاور; ۰ = غیرمرتبط|
|w₃ = ۰.۲۰|۰–۱۰۰|`R_tech`|`ReliabilityScore`|score × ۲۰|
|w₄ = ۰.۱۵|۰–۱۰۰|`H_history`|تعداد شیفت‌های قبلی در این داروخانه|۱۰۰ = ≥۳; ۵۰ = ۱-۲; ۰ = ۰|

**Hard Filter (پیش از محاسبه):**
- تطابق `RequiredSoftware` در سطح ≥ `MinProficiencyLevel`
- `Pharmacy.DistrictId` در لیست `Technician.ServiceDistricts` باشد
- `Status == Active`

### Domain Service — `DispatchOrchestrator`

|فاز|زمان|مخاطب|محدوده منطقه‌ای|شرط ورود|
|---|---|---|---|---|
|فاز ۱ (VIP)|T+۰ → T+۵ دقیقه|تکنسین‌های `H_history ≥ ۱` با `R_tech ≥ ۴.۵`|همان منطقه داروخانه|فوری (`Immediate`)|
|فاز ۲ (Golden)|T+۵ → T+۱۵ دقیقه|بالاترین Score|همان منطقه + مناطق مجاور|—|
|فاز ۳ (Public)|T+۱۵ → ∞|تمام Active|همه مناطقی که تکنسین تحت پوشش دارد|—|
|فاز ۴ (Escalation)|T+۳۰ → ∞|SMS به تمام تکنسین‌های منطقه|گسترش به مناطق دورتر|فقط Immediate|

**Saga: Timeout Matching Saga**
- `SchedulePhase1` → `SchedulePhase2` → `SchedulePhase3` → `SchedulePhase4`
- جبران: اگر شیفت `Assigned` شد → Cancel تایمرهای بعدی

**رویداد خروجی:**
- `CandidatesFoundEvent{ShiftId, CandidateIds[]}`

---

## ۴. کانتکست آنبوردینگ لحظه‌ای (Context Injection / Playbook)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|تولید و تحویل بسته اطلاعاتی شیفت به تکنسین به محض قطعی شدن|
|**هسته**|`ShiftPass` (Value Object) — immutable|

|بلوک|محتوا|منبع|
|---|---|---|
|`PharmacyInfo`|نام + آدرس + تلفن + منطقه|`Pharmacy`|
|`LayoutMap`|چیدمان داروهای پرمصرف، یخچال، تحت کنترل|`Pharmacy.OnboardingPlaybook`|
|`SoftwareCheatSheet`|نام نرم‌افزار + ورژن + رمز مهمان + کلیدهای میانبر|`Pharmacy.PrimarySoftware` + `Playbook`|
|`ContactInfo`|نام مسئول فنی + شماره تماس امن (Masked Number)|سیستم تماس|
|`ShiftRules`|قوانین پوشش، استراحت، تحویل صندوق|`Pharmacy.OnboardingPlaybook`|

**رویداد خروجی:** `ShiftPassGeneratedEvent{ShiftId, TechnicianId, PassId}`

---

## ۵. کانتکست حضور و غیاب (Attendance & QR Check-in)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|اعتبارسنجی حضور فیزیکی تکنسین با QR Code پویا + تأیید دستی|
|**هسته (Agg. Root)**|`AttendanceRecord`|

### موجودیت AttendanceRecord

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتا|
|`ShiftId`|Guid (Unique Index)|✓|یک شیفت = یک رکورد حضور|
|`TechnicianId`|Guid|✓|FK به تکنسین|
|`PharmacyId`|Guid|✓|FK به داروخانه|
|`CheckInTime`|DateTimeOffset?|✗|زمان ثبت ورود (QR + تأیید)|
|`CheckOutTime`|DateTimeOffset?|✗|زمان ثبت خروج|
|`CheckInMethod`|TinyInt|✓|۱=QR Code, ۲=ManualConfirm|
|`Status`|AttendanceStatusEnum|✓|→ زیر|
|`IsVerified`|Boolean|✓|آیا تأیید نهایی شده؟|
|`QrCode`|String?|✗|GUID منقضی‌شونده در ۶۰ ثانیه|

**مقادیر `AttendanceStatusEnum`:**
```
Pending ──→ CheckedIn ──→ CheckedOut
  │            │
  ▼            ▼
NoShow       Late ──→ CheckedOut
                 │
                 ▼
              Disputed
```

**Invariants:**
- `CheckOutTime ≥ CheckInTime` (اگر هر دو مقدار داشته باشند)
- `Status == CheckedIn` ⇒ `CheckInTime ≠ null`
- `Status == CheckedOut` ⇒ `CheckInTime ≠ null AND CheckOutTime ≠ null`

### مکانیزم احراز حضور

|روش|مسئول|سناریو|
|---|---|---|
|**QR Code پویا**|تکنسین|اسکن QR روی مانیتور داروخانه — بلافاصله Check-in ثبت می‌شود|
|**تأیید دستی**|مسئول فنی|فعال کردن دکمه «تأیید حضور» در اپ داروخانه — برای موارد QR failed|
|**ترکیبی**|هر دو|QR ثبت می‌کند + مسئول فنی تأیید نهایی می‌کند|

### Saga: EarlyWarning (زمانی، بدون GPS)

- **T-30min:** اگر تکنسین وضعیت را به «در مسیرم» تغییر نداده → Push Notification
- **T-15min:** اگر وضعیت هنوز «در مسیرم» نیست → SMS + هشدار به داروخانه
- **T-5min:** اگر Check-in ثبت نشده → هشدار «در معرض NoShow» به داروخانه
- **جبران:** Check-in ثبت شد → همه هشدارها متوقف

**رویداد خروجی:**
- `CheckInCompletedEvent{ShiftId, TechnicianId, CheckInTime, Method}`
- `CheckOutCompletedEvent{ShiftId, TechnicianId, CheckOutTime}` → کانتکست مالی
- `AttendanceAnomalyEvent{ShiftId, AnomalyType}` — NoShow, Late

---

## ۶. کانتکست مالی و امانت‌داری (Escrow & Settlement)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|مدیریت کیف پول‌ها، مسدودی وجه، تسویه خودکار، جریمه|
|**هسته (Agg. Root)**|`Wallet`, `EscrowHold`|

### Wallet

|فیلد|نوع|توضیح|Invariant|
|---|---|---|---|
|`Id`|Guid|شناسه یکتا|—|
|`OwnerId`|Guid|FK|—|
|`OwnerType`|UserTypeEnum|Pharmacy / Technician|—|
|`AvailableBalance`|Decimal|موجودی قابل استفاده|≥ ۰|
|`HeldBalance`|Decimal|موجودی مسدودشده|≥ ۰|

**Invariant:** `AvailableBalance + HeldBalance` ≥ ۰

### چرخه مسدودی وجه

```
ShiftAssigned → Hold(TotalAmount) → CheckOutConfirmed → Release(TechWallet)
                                           ↓
                                    RefundToPharmacy
                                    (در صورت اختلاف/لغو)
```

**قوانین جریمه لغو:**

|طرف|مهلت|جریمه|تأثیر بر امتیاز|
|---|---|---|---|
|تکنسین|< ۲ ساعت|۲۰٪ مبلغ + انتقال به داروخانه|کاهش -۰.۵|
|تکنسین|≥ ۲ ساعت|بدون جریمه|بدون تأثیر|
|داروخانه|بدون دلیل|۴۰٪ مبلغ به تکنسین|کاهش -۰.۳|

**رویداد خروجی:**
- `FundsHeldEvent`, `FundsReleasedEvent`, `PenaltyAppliedEvent`, `WalletLowBalanceEvent`

---

## ۷. کانتکست رتبه‌بندی و بازخورد (Reputation & Feedback)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|ثبت و افشای مشروط ارزیابی‌های دوطرفه|
|**هسته (Agg. Root)**|`ShiftReview`|

|فیلد|نوع|محدوده|
|---|---|---|
|`Id`|Guid|—|
|`ShiftId`|Guid|FK یکتا|
|`ReviewerId`|Guid|فرستنده|
|`RevieweeId`|Guid|گیرنده|
|`ReviewerType`|UserTypeEnum|Pharmacy / Technician|
|`Rating`|Int|۱–۵|
|`PunctualityScore`|Int|۱–۵|
|`SoftwareSkillScore`|Int|۱–۵ (فقط داروخانه)|
|`Comment`|String|max ۵۰۰|
|`IsVisible`|Boolean|Double-Blind|

**Double-Blind:** نظر تا ثبت نظر مقابل یا ۲۴ ساعت `IsVisible = false`

**رویداد خروجی:**
- `ReviewSubmittedEvent` → بروزرسانی `ReliabilityScore`
- `ReviewPairCompletedEvent`

---

## نقشه ارتباط بین کانتکست‌ها (Event Map)

```
[Identity & Competency] ──→ (TechnicianVerifiedEvent) ──→ [Shift Lifecycle]

[Shift Lifecycle] ──→ (ShiftCreatedEvent) ──→ [Matching Engine]
                      (ShiftAssignedEvent) ──→ [Escrow] + [Attendance] + [Playbook]
                      (ShiftCancelledEvent) ──→ [Escrow]

[Matching Engine] ──→ (CandidatesFoundEvent) ──→ [Shift Lifecycle]

[Attendance] ──→ (CheckOutCompletedEvent) ──→ [Escrow]

[Escrow] ──→ (FundsReleasedEvent) ──→ [Reputation] (فعال‌سازی فرم ارزیابی)

[Reputation] ──→ (ReviewSubmittedEvent) ──→ [Identity & Competency] (بروزرسانی امتیاز)
```
