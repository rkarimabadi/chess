# تفکیک مرزهای سامانه (Bounded Contexts)

> معماری سامانه بر اساس اصول Domain-Driven Design (DDD) به ۷ باندد کانتکست مجزا تفکیک شده است. هر کانتکست دارای موجودیت‌ها (Entities)، رویدادهای خروجی (Integration Events) و منطق اختصاصی خود است.
>
> **تغییر معماری:** به جای GPS/موقعیت جغرافیایی، از سامانه «منطقه (District) + QR Code پویا + وضعیت دستی» استفاده می‌شود.

---

## ۱. کانتکست هویت، صلاحیت و ماتریس مهارت (Identity & Competency)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|ثبت، احراز و نگهداشت پروفایل طرفین + ماتریس مهارت‌ها + مناطق تحت پوشش|
|**هسته (Agg. Root)**|`Technician`, `Pharmacy`|
|**جدول مرجع**|`Districts` — ساختار سلسله‌مراتبی: Province > City > District > Neighborhood|
|**الگوی Context Map**|Core Domain — هسته اعتماد پلتفرم|

### جدول مرجع Districts

|فیلد|نوع|توضیح|
|---|---|---|
|`Id`|Guid|شناسه یکتا|
|`Province`|String|استان (مثلاً تهران)|
|`City`|String|شهر (مثلاً تهران)|
|`Name`|String|نام منطقه (مثلاً منطقه ۱۲، شهرک غرب)|
|`ParentDistrictId`|Guid?|منطقه والد (برای سلسله‌مراتب)|

**AdjacentDistricts:** جدول جداگانه برای تعریف مناطق مجاور (برای گسترش فاز ۲)

### پروفایل تکنسین

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتای سامانه‌ای|
|`UserId`|Guid|✓|FK به Auth System|
|`FullName`|String|✓|نام و نام خانوادگی|
|`NationalCode`|String (۱۰ رقمی)|✓|کد ملی منحصربه‌فرد — **Unique Constraint**|
|`PhoneNumber`|String|✓|شماره تماس اصلی|
|`Status`|TechnicianStatusEnum|✓|`PendingVerification` → `Active` → `Suspended`|
|`ReliabilityScore`|Decimal (۰-۵)|✓|محاسبه‌شده از رویدادهای کانتکست ۷|
|`ServiceDistricts`|List<DistrictId>|✓|مناطق تحت پوشش — حداقل یک منطقه|
|`SoftwareSkills`|List|✓|ماتریس تسلط نرم‌افزاری|
|`Certificates`|List|✗|مدارک و گواهی‌نامه‌ها|

**Invariants:**
- حداقل یک منطقه در `ServiceDistricts` انتخاب شده باشد
- `ReliabilityScore` بین ۰ و ۵
- تکنسین `Suspended` نمی‌تواند شیفت جدید بپذیرد

**ماتریس مهارت نرم‌افزاری (TechnicianSoftwareSkill):**
- `SoftwareId: SoftwareTypeEnum` (RayanTab, EmenAfzar, Sharpel, Hami, Simorgh, ...)
- `ProficiencyLevel: ProficiencyLevelEnum` (Beginner, Intermediate, Expert)
- **Invariant:** حداقل یک نرم‌افزار در سطح `Intermediate` یا بالاتر

**Domain Service — `SkillVerificationService`:**
- ورودی: `TechnicianId` + `PharmacySoftwareType`
- خروجی: `(IsQualified: bool, MatchLevel: ProficiencyLevelEnum)`

### پروفایل داروخانه

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتا|
|`OwnerUserId`|Guid|✓|FK به مالک|
|`Name`|String|✓|نام داروخانه|
|`LicenseNumber`|String|✓|شماره پروانه تأسیس — **Unique Constraint**|
|`DistrictId`|Guid|✓|منطقه داروخانه (FK → Districts)|
|`Address`|AddressValueObject|✓|استان، شهر، خیابان، کدپستی|
|`PrimarySoftware`|SoftwareTypeEnum|✓|نرم‌افزار اصلی|
|`SoftwareVersion`|String|✗|نسخه نرم‌افزار|
|`PhoneNumber`|String|✓|شماره تماس|
|`OnboardingPlaybook`|PlaybookValueObject|✗|راهنمای آنبوردینگ|

**Repository Contracts:**
- `ITechnicianRepository`: `GetById`, `FindQualified(SoftwareType, DistrictId, MinScore)`, `GetByPhone`, `FindByDistrict(DistrictId)`
- `IPharmacyRepository`: `GetById`, `FindByDistrict(DistrictId)`

**Anti-Corruption Layer (ACL):**
- نگاشت `ExternalUserId` از Auth Provider به `UserId` داخلی

**رویدادهای خروجی:**
- `TechnicianVerifiedEvent{TechnicianId, VerifiedAt}`
- `PharmacyProfileUpdatedEvent{PharmacyId, UpdatedFields}`
- `ReliabilityScoreChangedEvent{TechnicianId, OldScore, NewScore}`

---

## ۲. کانتکست چرخه حیات شیفت (Shift Lifecycle)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|ثبت، انتشار، وضعیت‌سنجی و خاتمه درخواست‌های شیفت|
|**هسته (Agg. Root)**|`ShiftRequest`, `ShiftCandidate`|
|**زبان ubiquitous**|«شیفت فوری»، «فراخوان»، «متقاضی»، «پیشنهاد»|
|**الگوی Context Map**|Core Domain — فرآیند اصلی کسب‌وکار|

### موجودیت ShiftRequest

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتا|
|`PharmacyId`|Guid|✓|FK به داروخانه|
|`AssignedTechnicianId`|Guid?|✗|تا زمان تأیید null|
|`Status`|ShiftStatusEnum|✓|→ ماشین حالت|
|`UrgencyLevel`|UrgencyLevelEnum|✓|Immediate / SameDay / Scheduled|
|`StartTime`|DateTimeOffset|✓|شروع شیفت|
|`EndTime`|DateTimeOffset|✓|پایان شیفت|
|`RequiredSoftware`|SoftwareTypeEnum|✓|نرم‌افزار الزامی|
|`MinProficiencyLevel`|ProficiencyLevelEnum|✓|حداقل سطح تسلط|
|`RequiredRole`|RoleEnum|✓|Dispenser / Cosmetics / Operator|
|`Pricing`|ShiftPricingValueObject|✓|→ زیر|
|`PharmacyDistrictId`|Guid|✓|کپی از منطقه داروخانه (برای فیلتر تطبیق)|
|`CreatedAt`|DateTimeOffset|✓|زمان ثبت|

### Value Object — ShiftPricing

|فیلد|نوع|توضیح|
|---|---|---|
|`BaseHourlyRate`|Decimal|نرخ پایه ساعتی|
|`UrgencyBonus`|Decimal|پاداش اضطرار|
|`PlatformFee`|Decimal|کارمزد پلتفرم (درصدی از مجموع)|
|`TotalAmount`|Decimal|جمع کل|

**Invariant:** `TotalAmount` = مجموع اجزاء

### سطوح اضطرار (UrgencyLevel)

|مقدار|فاصله تا شروع|پاداش پیش‌فرض|رفتار فراخوان|
|---|---|---|---|
|`Immediate`|< ۳ ساعت|+۲۰٪|فوری به همه سطوح|
|`SameDay`|۳–۲۴ ساعت|+۱۰٪|استاندارد با اولویت بالا|
|`Scheduled`|> ۲۴ ساعت|۰|عادی|

### ماشین حالت شیفت — کامل

```
State     │  Trigger                │  Guard                              │  Action
──────────┼─────────────────────────┼─────────────────────────────────────┼─────────────────────
Draft     │  Publish()              │  Pricing.TotalAmount ≥ 0            │ → Open, ShiftCreatedEvent
Open      │  Assign(techId)         │  HasCandidate(techId) = true        │ → Assigned, ShiftAssignedEvent
Open      │  Cancel()               │  Candidates.Count = 0               │ → Cancelled
Open      │  ExpireTimeout()        │  CreatedAt + 30min بدون کاندیدا     │ → Cancelled
Assigned  │  Start(techId)          │  Now ≥ StartTime                    │ → InProgress
Assigned  │  Cancel(initiator)      │  ValidCancelCondition()             │ → Cancelled, PenaltyEvent
InProgress│  Complete()             │  CheckOutConfirmed = true           │ → Completed
Completed │  Settle()               │  Automatic (پس از Review)            │ → Settled
```

**Domain Service — `ShiftPricingCalculator`:**
- ورودی: `UrgencyLevel`, `DurationHours`, `BaseRate`, `PharmacyWalletBalance`
- خروجی: `ShiftPricingValueObject`

**رویدادهای خروجی:**
- `ShiftCreatedEvent{ShiftId, PharmacyId, UrgencyLevel, RequiredSoftware, DistrictId}` → موتور تطبیق
- `ShiftAssignedEvent{ShiftId, TechnicianId, Pricing}` → کانتکست مالی + حضور + آنبوردینگ
- `ShiftCompletedEvent{ShiftId, TechnicianId}` → کانتکست مالی
- `ShiftCancelledEvent{ShiftId, Initiator, Penalty}` → کانتکست مالی

---

## ۳. کانتکست موتور تطبیق (Smart Matching Engine)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|محاسبه نمره تطبیق، انتشار پلکانی با گسترش منطقه‌ای|
|**بدون Entity مستقل**|Stateless — خروجی به `ShiftCandidate` در کانتکست ۲|
|**الگوی Context Map**|Supporting Subdomain — الگوریتم‌محور|

### Domain Service — `MatchingService`

```
Score = w₁·S_soft + w₂·D_district + w₃·R_tech + w₄·H_history
```

|وزن|محدوده|متغیر|منبع داده|توضیح|
|---|---|---|---|---|
|w₁ = ۰.۴|۰ / ۱۰۰|`S_soft`|`Technician.SoftwareSkills`|۱۰۰ = تطابق کامل; ۰ = عدم تطابق → **حذف قطعی**|
|w₂ = ۰.۲۵|۰ / ۵۰ / ۱۰۰|`D_district`|`ServiceDistricts` vs `Pharmacy.DistrictId` + AdjacentDistricts|۱۰۰ = همان منطقه; ۵۰ = منطقه مجاور; ۰ = غیرمرتبط|
|w₃ = ۰.۲۰|۰–۱۰۰|`R_tech`|`ReliabilityScore`|score × ۲۰|
|w₄ = ۰.۱۵|۰–۱۰۰|`H_history`|تعداد شیفت قبلی در این داروخانه|۱۰۰ = ≥۳; ۵۰ = ۱-۲; ۰ = ۰|

**Hard Filter (پیش از محاسبه):**
- تطابق `RequiredSoftware` با سطح ≥ `MinProficiencyLevel`
- `Pharmacy.DistrictId` در `Technician.ServiceDistricts` (یا مناطق مجاور در فاز ۲)
- `Status == Active`

### Domain Service — `DispatchOrchestrator`

|فاز|زمان|مخاطب|دامنه منطقه‌ای|شرط|
|---|---|---|---|---|
|فاز ۱ (VIP)|T+۰ → T+۵ دقیقه|`H_history ≥ ۱` + `R_tech ≥ ۴.۵`|همان منطقه داروخانه|فوری|
|فاز ۲ (Golden)|T+۵ → T+۱۵ دقیقه|بالاترین Score|همان منطقه + مناطق مجاور|—|
|فاز ۳ (Public)|T+۱۵ → ∞|تمام Active|همه مناطق تحت پوشش تکنسین|—|
|فاز ۴ (Escalation)|T+۳۰ → ∞|SMS به همه|گسترش به مناطق دورتر|فقط Immediate|

**Saga: Timeout Matching Saga**
- `SchedulePhase1` → `SchedulePhase2` → `SchedulePhase3` → `SchedulePhase4`
- جبران: اگر `Assigned` شد → Cancel تایمرهای بعدی

**رویداد خروجی:**
- `CandidatesFoundEvent{ShiftId, CandidateIds[]}`

---

## ۴. کانتکست آنبوردینگ لحظه‌ای (Context Injection / Playbook)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|تولید و تحویل بسته اطلاعاتی به محض قطعی شدن|
|**هسته**|`ShiftPass` (Value Object) — immutable|

|بلوک|محتوا|منبع|
|---|---|---|
|`PharmacyInfo`|نام + آدرس + منطقه + تلفن|`Pharmacy`|
|`LayoutMap`|چیدمان داروها، یخچال، تحت کنترل|`Pharmacy.OnboardingPlaybook`|
|`SoftwareCheatSheet`|نام نرم‌افزار + ورژن + رمز مهمان + کلیدهای میانبر|`Pharmacy.PrimarySoftware` + `Playbook`|
|`ContactInfo`|نام مسئول فنی + شماره تماس امن (Masked Number)|سیستم تماس|
|`ShiftRules`|قوانین پوشش، استراحت، تحویل صندوق|`Pharmacy.OnboardingPlaybook`|

**رویداد خروجی:** `ShiftPassGeneratedEvent{ShiftId, TechnicianId, PassId}`

---

## ۵. کانتکست حضور و غیاب (Attendance & QR Check-in)

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|اعتبارسنجی حضور فیزیکی با QR Code پویا + تأیید دستی|
|**هسته (Agg. Root)**|`AttendanceRecord`|

### موجودیت AttendanceRecord

|فیلد|نوع|اجباری|توضیح|
|---|---|---|---|
|`Id`|Guid|✓|شناسه یکتا|
|`ShiftId`|Guid (Unique Index)|✓|یک شیفت = یک رکورد|
|`TechnicianId`|Guid|✓|FK به تکنسین|
|`PharmacyId`|Guid|✓|FK به داروخانه|
|`CheckInTime`|DateTimeOffset?|✗|زمان ثبت ورود|
|`CheckOutTime`|DateTimeOffset?|✗|زمان ثبت خروج|
|`CheckInMethod`|TinyInt|✓|۱=QR, ۲=ManualConfirm|
|`Status`|AttendanceStatusEnum|✓|→ زیر|
|`IsVerified`|Boolean|✓|تأیید نهایی حضور|
|`QrCode`|String?|✗|GUID منقضی‌شونده در ۶۰ ثانیه|
|`QrExpiresAt`|DateTimeOffset?|✗|زمان انقضای QR|

**مقادیر `AttendanceStatusEnum` و ماشین حالت:**
```
Pending ──→ CheckedIn ──→ CheckedOut
  │            │
  ▼            ▼
NoShow       Late ──→ CheckedOut
                 │
                 ▼
              Disputed
```

**Invariants:**
- `CheckOutTime ≥ CheckInTime` (اگر هر دو مقدار داشته باشند)
- `Status == CheckedIn` ⇒ `CheckInTime ≠ null`
- `Status == CheckedOut` ⇒ `CheckInTime ≠ null AND CheckOutTime ≠ null`

### Domain Service — `AttendanceVerificationService`

|روش|توضیح|اعتبارسنجی|
|---|---|---|
|**QR Code پویا**|اسکن QR روی مانیتور داروخانه — QR شامل GUID + timestamp|بررسی `QrExpiresAt > Now` و عدم استفاده مجدد|
|**تأیید دستی**|مسئول فنی دکمه «تأیید حضور» را می‌زند|احراز هویت مسئول فنی|
|**ترکیبی**|هر دو مرحله انجام می‌شود|امنیت بالاتر|

### Saga: EarlyWarning (زمانی، بدون GPS)

- **T-30min:** اگر `TechnicianStatus != OnTheWay` → Push Notification
- **T-15min:** اگر هنوز `OnTheWay` نیست → SMS + هشدار به داروخانه
- **T-5min:** اگر Check-in ثبت نشده → هشدار NoShow قریب‌الوقوع
- **جبران:** Check-in ثبت شد → همه هشدارها متوقف

**رویداد خروجی:**
- `CheckInCompletedEvent{ShiftId, TechnicianId, CheckInTime, Method}`
- `CheckOutCompletedEvent{ShiftId, TechnicianId, CheckOutTime}` → کانتکست مالی
- `AttendanceAnomalyEvent{ShiftId, AnomalyType}` — NoShow, Late

---

## ۶. کانتکست مالی و امانت‌داری (Escrow & Settlement)

*(بدون تغییر — این کانتکست به GPS وابسته نیست)*

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|مدیریت کیف پول، مسدودی وجه، تسویه، جریمه|
|**هسته (Agg. Root)**|`Wallet`, `EscrowHold`|
|**الگوی Context Map**|Core Domain — اعتماد مالی|

### Wallet

|فیلد|نوع|توضیح|Invariant|
|---|---|---|---|
|`Id`|Guid|شناسه|—|
|`OwnerId`|Guid|FK|—|
|`OwnerType`|UserTypeEnum|Pharmacy / Technician|—|
|`AvailableBalance`|Decimal|موجودی قابل استفاده|≥ ۰|
|`HeldBalance`|Decimal|موجودی مسدودشده|≥ ۰|

### EscrowHold

|فیلد|نوع|توضیح|
|---|---|---|
|`Id`|Guid|شناسه|
|`ShiftId`|Guid (UQ)|FK|
|`PharmacyWalletId`|Guid|FK|
|`TechWalletId`|Guid|FK|
|`Amount`|Decimal|مبلغ مسدودشده|
|`Status`|EscrowStatusEnum|Held → Released / Refunded / PartialRefund|
|`CreatedAt` / `ReleasedAt`|DateTimeOffset|زمان‌ها|

**قوانین جریمه لغو:**

|طرف|مهلت|جریمه|تأثیر بر امتیاز|
|---|---|---|---|
|تکنسین|< ۲ ساعت|۲۰٪ مبلغ|کاهش -۰.۵|
|تکنسین|≥ ۲ ساعت|بدون جریمه|بدون تأثیر|
|داروخانه|بدون دلیل|۴۰٪ به تکنسین|کاهش -۰.۳|
|داروخانه|فورس ماژور|بدون جریمه|بدون تأثیر|

**Saga: Shift Settlement Saga**
1. `Hold` — مسدودی وجه
2. انتظار `CheckOutCompletedEvent`
3. `Release` — آزادسازی
4. `FundsReleasedEvent`
- جبران: `ShiftCancelledEvent` → `Refund` یا `ApplyPenalty`

**رویداد خروجی:**
- `FundsHeldEvent`, `FundsReleasedEvent`, `PenaltyAppliedEvent`, `WalletLowBalanceEvent`

---

## ۷. کانتکست رتبه‌بندی و بازخورد (Reputation & Feedback)

*(بدون تغییر — این کانتکست به GPS وابسته نیست)*

|قلمرو|توضیح|
|---|---|
|**مسئولیت**|ارزیابی دوطرفه نابینا، محاسبه شاخص‌های اعتبار|
|**هسته (Agg. Root)**|`ShiftReview`|

|فیلد|نوع|محدوده|
|---|---|---|
|`Id`|Guid|—|
|`ShiftId`|Guid (UQ)|FK|
|`ReviewerId`|Guid|فرستنده|
|`RevieweeId`|Guid|گیرنده|
|`ReviewerType`|UserTypeEnum|Pharmacy / Technician|
|`Rating`|Int|۱–۵|
|`PunctualityScore`|Int|۱–۵|
|`SoftwareSkillScore`|Int|۱–۵ (فقط داروخانه)|
|`Comment`|String|max ۵۰۰|
|`IsVisible`|Boolean|Double-Blind|

**شاخص‌های محاسبه‌شده:**

|شاخص|فرمول|کاربرد|
|---|---|---|
|`ReliabilityRate`|(Completed / TotalAccepted) × ۱۰۰|فیلتر سخت تطبیق|
|`AvgRating`|میانگین وزنی ۶ ماه|نمره نرم تطبیق|
|`CancellationRate`|(Cancels / Total) × ۱۰۰|کاهش اولویت در > ۲۰٪|

**رویداد خروجی:**
- `ReviewSubmittedEvent` → بروزرسانی `ReliabilityScore` در کانتکست ۱
- `ReviewPairCompletedEvent` — هر دو Visible شدند

---

## نقشه ارتباط بین کانتکست‌ها (Event Map)

```
[Identity & Competency]
  ├─ (TechnicianVerifiedEvent) ──────────────→ [Shift Lifecycle]
  └─ (ReliabilityScoreChangedEvent) ─────────→ [Matching Engine]

[Shift Lifecycle]
  ├─ (ShiftCreatedEvent) ─────────────────────→ [Matching Engine]
  ├─ (ShiftAssignedEvent) ──┬────────────────→ [Escrow]
  │                          ├────────────────→ [Attendance]
  │                          └────────────────→ [Playbook]
  ├─ (ShiftCompletedEvent) ──────────────────→ [Escrow]
  └─ (ShiftCancelledEvent) ──────────────────→ [Escrow]

[Matching Engine]
  └─ (CandidatesFoundEvent) ─────────────────→ [Shift Lifecycle]

[Attendance]
  └─ (CheckOutCompletedEvent) ───────────────→ [Escrow]

[Escrow]
  ├─ (FundsReleasedEvent) ───────────────────→ [Reputation]
  └─ (PenaltyAppliedEvent) ──────────────────→ [Identity & Competency]

[Reputation]
  └─ (ReviewSubmittedEvent) ─────────────────→ [Identity & Competency]
```

---

## ضمیمه: تصمیمات معماری (Architecture Decision Records)

|ADR|تصمیم|دلیل|
|---|---|---|
|ADR-001|ارتباط بین کانتکست‌ها فقط از طریق Integration Events|جلوگیری از Coupling مستقیم|
|ADR-002|موتور تطبیق Stateless|مقیاس‌پذیری بالا|
|ADR-003|`ShiftPass` Immutable|جلوگیری از تغییر اطلاعات میانی|
|ADR-004|جریمه لغو در کانتکست مالی|جداسازی مسئولیت‌ها|
|ADR-005|Double-Blind در سطح کانتکست|امنیت Visibility|
|**ADR-006**|**جایگزینی GPS با District + QR + Manual Status**|**عدم دسترسی به موقعیت جغرافیایی**|
|**ADR-007**|**اضافه کردن جدول Districts + AdjacentDistricts**|**پشتیبانی از تطبیق منطقه‌ای و گسترش پلکانی**|
