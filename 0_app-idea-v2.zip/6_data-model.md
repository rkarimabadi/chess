# مدل داده‌ای (Data Model)

> ساختار داده‌ها بر اساس اصول Domain-Driven Design (DDD) — جایگزینی GPS/GeoPoint با **District + QR Code + Manual Status**.

---

## ۰. جدول مرجع مناطق (Districts)

```sql
CREATE TABLE Districts (
    Id              UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    Province        NVARCHAR(50)        NOT NULL,
    City            NVARCHAR(50)        NOT NULL,
    Name            NVARCHAR(100)       NOT NULL,  -- نام منطقه (مثلاً "منطقه ۱۲", "شهرک غرب")
    ParentDistrictId UNIQUEIDENTIFIER   NULL REFERENCES Districts(Id),

    CONSTRAINT UQ_District_Unique 
        UNIQUE (Province, City, Name)
);

CREATE INDEX IX_Districts_Parent ON Districts(ParentDistrictId);
```

```sql
CREATE TABLE AdjacentDistricts (
    DistrictId      UNIQUEIDENTIFIER    NOT NULL REFERENCES Districts(Id),
    AdjacentDistrictId UNIQUEIDENTIFIER NOT NULL REFERENCES Districts(Id),

    CONSTRAINT PK_AdjacentDistricts 
        PRIMARY KEY (DistrictId, AdjacentDistrictId),
    CONSTRAINT CK_AdjacentDistricts_Different 
        CHECK (DistrictId <> AdjacentDistrictId)
);
```

---

## ۱. کانتکست هویت و صلاحیت (Identity & Competency)

### Technician (Aggregate Root)

```sql
CREATE TABLE Technicians (
    Id              UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    UserId          UNIQUEIDENTIFIER    NOT NULL REFERENCES AuthUsers(Id),
    FirstName       NVARCHAR(50)        NOT NULL,
    LastName        NVARCHAR(50)        NOT NULL,
    NationalCode    NVARCHAR(10)        NOT NULL UNIQUE,
    PhoneNumber     NVARCHAR(15)        NOT NULL,
    Status          TINYINT             NOT NULL DEFAULT 0,
        -- 0=PendingVerification, 1=Active, 2=Suspended
    ReliabilityScore DECIMAL(3,2)       NOT NULL DEFAULT 5.00,
        -- محدوده ۰.۰۰ تا ۵.۰۰
    CreatedAt       DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    UpdatedAt       DATETIME2           NULL,

    CONSTRAINT CK_Technician_ScoreRange 
        CHECK (ReliabilityScore >= 0 AND ReliabilityScore <= 5),
    CONSTRAINT CK_Technician_NationalCode 
        CHECK (LEN(NationalCode) = 10 AND NationalCode NOT LIKE '%[^۰-۹]%')
);

CREATE UNIQUE INDEX IX_Technicians_NationalCode ON Technicians(NationalCode);
CREATE INDEX IX_Technicians_Phone ON Technicians(PhoneNumber);
```

### TechnicianServiceDistrict (مناطق تحت پوشش تکنسین)

```sql
CREATE TABLE TechnicianServiceDistricts (
    TechnicianId    UNIQUEIDENTIFIER    NOT NULL REFERENCES Technicians(Id),
    DistrictId      UNIQUEIDENTIFIER    NOT NULL REFERENCES Districts(Id),

    CONSTRAINT PK_TechServiceDistrict 
        PRIMARY KEY (TechnicianId, DistrictId),
    CONSTRAINT FK_TechDistrict_Technician 
        FOREIGN KEY (TechnicianId) REFERENCES Technicians(Id) ON DELETE CASCADE
);

CREATE INDEX IX_TechDistrict_District ON TechnicianServiceDistricts(DistrictId);
```

### Pharmacy (Aggregate Root) — GeoPoint حذف شد، DistrictId جایگزین

```sql
CREATE TABLE Pharmacies (
    Id              UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    OwnerUserId     UNIQUEIDENTIFIER    NOT NULL REFERENCES AuthUsers(Id),
    Name            NVARCHAR(100)       NOT NULL,
    LicenseNumber   NVARCHAR(30)        NOT NULL UNIQUE,
    DistrictId      UNIQUEIDENTIFIER    NOT NULL REFERENCES Districts(Id),
    Province        NVARCHAR(50)        NOT NULL,
    City            NVARCHAR(50)        NOT NULL,
    StreetAddress   NVARCHAR(200)       NOT NULL,
    PostalCode      NVARCHAR(10)        NOT NULL,
    PhoneNumber     NVARCHAR(15)        NOT NULL,
    PrimarySoftwareId TINYINT           NOT NULL,
    SoftwareVersion NVARCHAR(20)        NULL,
    Playbook_Layout NVARCHAR(MAX)       NULL,
    Playbook_GuestUsername NVARCHAR(50) NULL,
    Playbook_GuestPassword NVARCHAR(50) NULL,
    Playbook_Rules  NVARCHAR(MAX)       NULL,
    CreatedAt       DATETIME2           NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT FK_Pharmacy_District 
        FOREIGN KEY (DistrictId) REFERENCES Districts(Id),
    CONSTRAINT FK_Pharmacy_User 
        FOREIGN KEY (OwnerUserId) REFERENCES AuthUsers(Id)
);

CREATE UNIQUE INDEX IX_Pharmacies_License ON Pharmacies(LicenseNumber);
CREATE INDEX IX_Pharmacies_District ON Pharmacies(DistrictId);
```

**JSON Serialization (API Response):**

```json
{
  "id": "3fa85f64-5717-4562-b3fc-2c963f66a700",
  "name": "داروخانه دکتر ابراهیمی",
  "district": {
    "id": "...",
    "province": "تهران",
    "city": "تهران",
    "name": "منطقه ۱۲"
  },
  "address": {
    "province": "تهران",
    "city": "تهران",
    "street": "میدان فردوسی",
    "postalCode": "۱۱۱۱۱۱۱۱۱۱"
  },
  "primarySoftware": "RayanTab",
  "onboardingPlaybook": {
    "layout": "داروی خارجی: قفسه A1-A5 | یخچال: انتهای سالن راست",
    "guestUsername": "guest",
    "guestPassword": "1234",
    "rules": "تحویل صندوق انتهای شیفت الزامی است"
  }
}
```

---

## ۲. کانتکست چرخه حیات شیفت (Shift Lifecycle)

### ShiftRequest (Aggregate Root) — GeoPoint حذف شد، PharmacyDistrictId جایگزین

```sql
CREATE TABLE ShiftRequests (
    Id                  UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    PharmacyId          UNIQUEIDENTIFIER    NOT NULL REFERENCES Pharmacies(Id),
    AssignedTechnicianId UNIQUEIDENTIFIER   NULL REFERENCES Technicians(Id),
    
    Status              TINYINT             NOT NULL DEFAULT 0,
    UrgencyLevel        TINYINT             NOT NULL,
    StartTime           DATETIME2           NOT NULL,
    EndTime             DATETIME2           NOT NULL,
    
    RequiredSoftwareId  TINYINT             NOT NULL,
    MinProficiencyLevel TINYINT             NOT NULL DEFAULT 2,
    RequiredRole        TINYINT             NOT NULL,
    
    BaseHourlyRate      DECIMAL(12,0)       NOT NULL,
    UrgencyBonus        DECIMAL(12,0)       NOT NULL DEFAULT 0,
    PlatformFee         DECIMAL(12,0)       NOT NULL,
    TotalAmount         DECIMAL(12,0)       NOT NULL,
    
    PharmacyDistrictId  UNIQUEIDENTIFIER    NOT NULL,
        -- کپی از District داروخانه برای کوئری تطبیق
    
    CreatedAt           DATETIME2           NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT FK_Shift_Pharmacy 
        FOREIGN KEY (PharmacyId) REFERENCES Pharmacies(Id),
    CONSTRAINT FK_Shift_Technician 
        FOREIGN KEY (AssignedTechnicianId) REFERENCES Technicians(Id),
    CONSTRAINT CK_Shift_Duration 
        CHECK (EndTime > StartTime),
    CONSTRAINT CK_Shift_TotalAmount 
        CHECK (TotalAmount = BaseHourlyRate * 
               DATEDIFF(HOUR, StartTime, EndTime) + UrgencyBonus + PlatformFee)
);

CREATE INDEX IX_Shift_Pharmacy ON ShiftRequests(PharmacyId);
CREATE INDEX IX_Shift_Status ON ShiftRequests(Status);
CREATE INDEX IX_Shift_District ON ShiftRequests(PharmacyDistrictId);
CREATE INDEX IX_Shift_Urgency ON ShiftRequests(UrgencyLevel, Status);
```

### ShiftCandidate (Entity)

```sql
CREATE TABLE ShiftCandidates (
    Id              UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    ShiftId         UNIQUEIDENTIFIER    NOT NULL REFERENCES ShiftRequests(Id),
    TechnicianId    UNIQUEIDENTIFIER    NOT NULL REFERENCES Technicians(Id),
    MatchingScore   DECIMAL(5,2)        NOT NULL,  -- ۰.۰۰ تا ۱۰۰.۰۰
    AppliedAt       DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    Status          TINYINT             NOT NULL DEFAULT 0,
        -- 0=Offered, 1=AcceptedByTech, 2=ConfirmedByPharmacy, 3=Rejected, 4=Expired

    CONSTRAINT FK_Candidate_Shift 
        FOREIGN KEY (ShiftId) REFERENCES ShiftRequests(Id) ON DELETE CASCADE,
    CONSTRAINT FK_Candidate_Technician 
        FOREIGN KEY (TechnicianId) REFERENCES Technicians(Id),
    CONSTRAINT CK_Candidate_Score 
        CHECK (MatchingScore >= 0 AND MatchingScore <= 100),
    CONSTRAINT UQ_Candidate_ShiftTech 
        UNIQUE (ShiftId, TechnicianId)
);

CREATE INDEX IX_Candidate_Shift ON ShiftCandidates(ShiftId);
CREATE INDEX IX_Candidate_Score ON ShiftCandidates(MatchingScore DESC);
```

---

## ۳. کانتکست حضور و غیاب (Attendance & QR Check-in) — GPS حذف شد

### AttendanceRecord (Aggregate Root)

```sql
CREATE TABLE AttendanceRecords (
    Id                  UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    ShiftId             UNIQUEIDENTIFIER    NOT NULL UNIQUE REFERENCES ShiftRequests(Id),
    TechnicianId        UNIQUEIDENTIFIER    NOT NULL REFERENCES Technicians(Id),
    PharmacyId          UNIQUEIDENTIFIER    NOT NULL REFERENCES Pharmacies(Id),
    
    CheckInTime         DATETIME2           NULL,
    CheckOutTime        DATETIME2           NULL,
    
    CheckInMethod       TINYINT             NOT NULL DEFAULT 0,
        -- 0=Pending, 1=QRCode, 2=ManualConfirm
    
    Status              TINYINT             NOT NULL DEFAULT 0,
        -- 0=Pending, 1=CheckedIn, 2=CheckedOut, 3=Late, 4=NoShow, 5=Disputed
    
    IsVerified          BIT                 NOT NULL DEFAULT 0,
        -- تأیید نهایی توسط مسئول فنی
    
    QrCode              NVARCHAR(36)        NULL,
        -- GUID منحصربه‌فرد — منقضی‌شونده در ۶۰ ثانیه
    QrExpiresAt         DATETIME2           NULL,
        -- زمان انقضای QR

    CONSTRAINT FK_Attendance_Shift 
        FOREIGN KEY (ShiftId) REFERENCES ShiftRequests(Id),
    CONSTRAINT CK_Attendance_CheckTime 
        CHECK (CheckOutTime IS NULL OR CheckInTime IS NULL OR CheckOutTime >= CheckInTime)
);

CREATE UNIQUE INDEX IX_Attendance_Shift ON AttendanceRecords(ShiftId);
CREATE INDEX IX_Attendance_Technician ON AttendanceRecords(TechnicianId);
```

**MongoDB Document Structure:**

```json
{
  "shiftId": "3fa85f64-5717-4562-b3fc-2c963f66a700",
  "technicianId": "...",
  "pharmacyId": "...",
  "checkIn": {
    "time": "2026-07-29T16:25:00Z",
    "method": "QRCode"
  },
  "checkOut": null,
  "status": "CheckedIn",
  "isVerified": true,
  "qrCode": "a1b2c3d4-...",
  "qrExpiresAt": "2026-07-29T16:26:00Z"
}
```

---

## ۴. کانتکست مالی و امانت‌داری (Escrow & Settlement)

*(بدون تغییر وابسته به GPS)*

### Wallet (Aggregate Root)

```sql
CREATE TABLE Wallets (
    Id              UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    OwnerId         UNIQUEIDENTIFIER    NOT NULL,
    OwnerType       TINYINT             NOT NULL,  -- 1=Pharmacy, 2=Technician
    AvailableBalance DECIMAL(12,0)      NOT NULL DEFAULT 0,
    HeldBalance     DECIMAL(12,0)       NOT NULL DEFAULT 0,
    UpdatedAt       DATETIME2           NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT CK_Wallet_Balances 
        CHECK (AvailableBalance >= 0 AND HeldBalance >= 0),
    CONSTRAINT UQ_Wallet_Owner 
        UNIQUE (OwnerId, OwnerType)
);

CREATE INDEX IX_Wallet_Owner ON Wallets(OwnerId, OwnerType);
```

### EscrowHold (Entity)

```sql
CREATE TABLE EscrowHolds (
    Id                  UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    ShiftId             UNIQUEIDENTIFIER    NOT NULL UNIQUE REFERENCES ShiftRequests(Id),
    PharmacyWalletId    UNIQUEIDENTIFIER    NOT NULL REFERENCES Wallets(Id),
    TechWalletId        UNIQUEIDENTIFIER    NOT NULL REFERENCES Wallets(Id),
    Amount              DECIMAL(12,0)       NOT NULL,
    Status              TINYINT             NOT NULL DEFAULT 0,
        -- 0=Held, 1=ReleasedToTech, 2=RefundedToPharmacy, 3=PartiallyRefunded
    CreatedAt           DATETIME2           NOT NULL DEFAULT GETUTCDATE(),
    ReleasedAt          DATETIME2           NULL,

    CONSTRAINT CK_Escrow_Amount CHECK (Amount > 0)
);

CREATE UNIQUE INDEX IX_Escrow_Shift ON EscrowHolds(ShiftId);
CREATE INDEX IX_Escrow_Status ON EscrowHolds(Status);
```

---

## ۵. کانتکست رتبه‌بندی و بازخورد (Reputation & Feedback)

*(بدون تغییر وابسته به GPS)*

### ShiftReview (Aggregate Root)

```sql
CREATE TABLE ShiftReviews (
    Id                  UNIQUEIDENTIFIER    PRIMARY KEY DEFAULT NEWID(),
    ShiftId             UNIQUEIDENTIFIER    NOT NULL REFERENCES ShiftRequests(Id),
    ReviewerId          UNIQUEIDENTIFIER    NOT NULL,
    RevieweeId          UNIQUEIDENTIFIER    NOT NULL,
    ReviewerType        TINYINT             NOT NULL,  -- 1=Pharmacy, 2=Technician
    Rating              TINYINT             NOT NULL CHECK (Rating BETWEEN 1 AND 5),
    PunctualityScore    TINYINT             NOT NULL CHECK (PunctualityScore BETWEEN 1 AND 5),
    SoftwareSkillScore  TINYINT             NULL CHECK (SoftwareSkillScore IS NULL OR (SoftwareSkillScore BETWEEN 1 AND 5)),
    Comment             NVARCHAR(500)       NULL,
    IsVisible           BIT                 NOT NULL DEFAULT 0,
    CreatedAt           DATETIME2           NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT FK_Review_Shift 
        FOREIGN KEY (ShiftId) REFERENCES ShiftRequests(Id),
    CONSTRAINT UQ_Review_ShiftReviewer 
        UNIQUE (ShiftId, ReviewerId)
);

CREATE INDEX IX_Review_Reviewee ON ShiftReviews(RevieweeId);
```

---

## ۶. Value Objectها

### DistrictInfoValueObject

|فیلد|نوع|توضیح|
|---|---|---|
|`DistrictId`|Guid|شناسه منطقه|
|`Province`|String|استان|
|`City`|String|شهر|
|`DistrictName`|String|نام منطقه|

### AddressValueObject

|فیلد|نوع|
|---|---|
|`Province`|String (max ۵۰)|
|`City`|String (max ۵۰)|
|`Street`|String (max ۲۰۰)|
|`PostalCode`|String (۱۰ رقمی)|

### ShiftPricingValueObject

|فیلد|نوع|فرمول|
|---|---|---|
|`BaseHourlyRate`|Decimal|—|
|`UrgencyBonus`|Decimal|—|
|`PlatformFee`|Decimal|(BaseTotal + Bonus) × FeeRate|
|`TotalAmount`|Decimal|BaseTotal + Bonus + Fee|

**Invariant:** `TotalAmount` == مجموع اجزاء

---

## ۷. Enums

### CheckInMethodEnum
```csharp
public enum CheckInMethod : byte {
    Pending = 0,
    QRCode = 1,
    ManualConfirm = 2
}
```

### TechnicianStatusEnum, ShiftStatusEnum, UrgencyLevelEnum, AttendanceStatusEnum, EscrowStatusEnum, SoftwareTypeEnum
*(بدون تغییر — مشابه نسخه قبل)*

---

## ۸. ERD متنی (Entity Relationship Diagram) — به‌روز شده

```
┌─────────────────────┐       ┌─────────────────────────┐
│     Districts       │       │       Pharmacies        │
├─────────────────────┤       ├─────────────────────────┤
│ Id (PK)             │──1:N──│ DistrictId (FK)         │
│ Province, City, Name│       │ OwnerUserId (FK)        │
│ ParentDistrictId    │       │ LicenseNumber (UQ)      │
└──────────┬──────────┘       │ PrimarySoftwareId       │
           │                  │ Playbook_*              │
           │ 1:N              └──────────┬──────────────┘
           ▼                             │
┌─────────────────────┐                  │ 1:N
│TechServiceDistricts │                  ▼
├─────────────────────┤       ┌─────────────────────────────┐
│ TechnicianId (FK)   │       │       ShiftRequests         │
│ DistrictId (FK)     │       ├─────────────────────────────┤
│ (PK: TechId+DistId) │       │ Id (PK)                     │
└──────────┬──────────┘       │ PharmacyId (FK)             │
           │ 1:N              │ PharmacyDistrictId (FK)     │
           ▼                  │ AssignedTechnicianId (FK)   │
┌─────────────────────┐       │ Status, UrgencyLevel        │
│    Technicians      │       │ StartTime, EndTime          │
├─────────────────────┤       │ Pricing_*                   │
│ Id (PK)             │       └──────────┬──────────────────┘
│ NationalCode (UQ)   │                  │ 1:N
│ Status              │                  ▼
│ ReliabilityScore    │       ┌─────────────────────────┐
└─────────────────────┘       │   AttendanceRecords     │
                              ├─────────────────────────┤
┌─────────────────────┐       │ ShiftId (FK) (UQ)       │
│  AdjacentDistricts  │       │ TechnicianId (FK)       │
├─────────────────────┤       │ CheckInTime, CheckOut   │
│ DistrictId (FK)     │       │ CheckInMethod (QR/Man)  │
│ AdjacentDistrictId  │       │ QrCode, QrExpiresAt    │
│ (PK: both)          │       │ IsVerified              │
└─────────────────────┘       └─────────────────────────┘

┌─────────────────────┐       ┌─────────────────────────┐
│      Wallets        │       │      EscrowHolds        │
├─────────────────────┤       ├─────────────────────────┤
│ Id (PK)             │       │ Id (PK)                 │
│ OwnerId, OwnerType  │       │ ShiftId (FK) (UQ)       │
│ AvailableBalance    │       │ PharmacyWalletId (FK)   │
│ HeldBalance         │       │ TechWalletId (FK)       │
│ (OwnerId+Type UQ)   │       │ Amount, Status          │
└─────────────────────┘       └─────────────────────────┘

┌─────────────────────┐
│    ShiftReviews     │
├─────────────────────┤
│ Id (PK)             │
│ ShiftId (FK)        │
│ ReviewerId          │
│ RevieweeId          │
│ Rating, Scores      │
│ IsVisible           │
│ (ShiftId+RevUQ)     │
└─────────────────────┘
```
